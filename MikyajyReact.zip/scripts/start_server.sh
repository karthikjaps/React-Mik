#!/bin/bash
# testing autodeployment.
cd /home/ubuntu/mikyajy-web/
pm2 start app.js
