import "@babel/polyfill";

import Nav from "./nav";

if (document.getElementById("hamburger")) {
  // eslint-disable-next-line no-unused-vars
  const nav = new Nav(document.getElementById("hamburger"));
}
