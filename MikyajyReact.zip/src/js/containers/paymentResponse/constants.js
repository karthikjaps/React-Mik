export const REDUCER_NAME = "paymentResponse";
export const EMAIL_QUERY_STRING_PARAM = "email";
export const PAYMENT_METHOD_QUERY_STRING_PARAM = "paymentmethod";
