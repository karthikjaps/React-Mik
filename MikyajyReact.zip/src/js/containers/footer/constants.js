export const REDUCER_NAME = "footer";
export const SET_QUICKLINKS = `${REDUCER_NAME}/SET_QUICKLINKS`;
export const SET_SOCIAL = `${REDUCER_NAME}/SET_SOCIAL`;
