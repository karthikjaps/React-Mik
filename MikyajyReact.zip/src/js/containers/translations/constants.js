export const REDUCER_NAME = "translations";
export const SET_TRANSLATIONS = `${REDUCER_NAME}/SET_TRANSLATIONS`;
export const SET_LOADING = `${REDUCER_NAME}/SET_LOADING`;
