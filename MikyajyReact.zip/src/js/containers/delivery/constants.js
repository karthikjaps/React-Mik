export const REDUCER_NAME = "catalogue";
