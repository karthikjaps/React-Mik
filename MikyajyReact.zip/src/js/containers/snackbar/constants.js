export const SUCCESS_QUERY_STRING_PARAM = "success";
export const PREVACTION_QUERY_STRING_PARAM = "action";
export const OBJECT_QUERY_STRING_PARAM = "object";
