export const REDUCER_NAME = "pageNotFound";
export const SET_PAGE_NOT_FOUND = `${REDUCER_NAME}/SET_PAGE_NOT_FOUND`;
