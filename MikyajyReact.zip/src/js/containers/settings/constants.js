export const REDUCER_NAME = "settings";
export const SET_PUSH_ENABLED = `${REDUCER_NAME}/SET_PUSH_ENABLED`;
