export const REDUCER_NAME = "routes";
export const SET_ROUTES = `${REDUCER_NAME}/SET_ROUTES`;
