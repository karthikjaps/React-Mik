export const REDUCER_NAME = "checkout";
