export const REDUCER_NAME = "storeLocator";
export const SET_LOADING = `${REDUCER_NAME}/SET_LOADING`;
export const SET_STORE_LOCATIONS = `${REDUCER_NAME}/SET_STORE_LOCATIONS`;

export const DATA_TTL = 60000;
