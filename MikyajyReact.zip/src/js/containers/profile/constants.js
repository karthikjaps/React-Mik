export const REDUCER_NAME = "profile";
export const SET_PROFILE = `${REDUCER_NAME}/SET_PROFILE`;
export const RESET_PROFILE = `${REDUCER_NAME}/RESET_PROFILE`;
