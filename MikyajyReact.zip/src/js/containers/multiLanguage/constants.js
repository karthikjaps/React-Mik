export const REDUCER_NAME = "multiLanguage";
export const SET_LANGS = `${REDUCER_NAME}/SET_LANGS`;
