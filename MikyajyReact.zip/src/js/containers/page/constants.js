export const REDUCER_NAME = "page";
export const SET_PAGE = `${REDUCER_NAME}/SET_PAGE`;
