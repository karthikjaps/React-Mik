import React from "react";

const CatalogueTitleSkeleton = () => (
  <div className="container-section__title catalogue-section__title catalogue-section__title--skeleton" />
);

export default CatalogueTitleSkeleton;
