export const returnUrlParamsRegEx = /returnUrlParams\s\=\s(.*?)\;/g;
export const PURCHASE_COMMAND = "PURCHASE";
export const DECIMAL_MULTIPLIER = 100;
