// default store and language
export const STORE_ID = "5";
export const LANG = "AR";
