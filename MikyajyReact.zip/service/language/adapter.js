export const toTranslations = data => data;
