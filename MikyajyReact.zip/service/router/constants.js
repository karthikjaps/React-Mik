export const TTL = 1800;
export const CHECK_PERIOD = 600;
