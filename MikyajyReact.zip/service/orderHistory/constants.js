export const DEFAULT_PAGE_SIZE = 10;
