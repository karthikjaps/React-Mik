export const NAVIGATION_TYPE = "categories";
export const MULTITIER_MENU_TYPE = "complex_grid";
export const TOP_TIER_MENU_TYPE = "horizontallist";
