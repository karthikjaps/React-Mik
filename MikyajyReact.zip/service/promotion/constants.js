export const MAIN_BANNER = "fullwidth";
export const MAIN_BANNER_MOBILE = "mobilewidth";
export const SECONDARY_BANNER = "secondary";
export const SUBHEADER_BANNER = "subheaderwidth";
