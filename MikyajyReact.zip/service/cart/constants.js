export const TAX_RATE = 0.05;
